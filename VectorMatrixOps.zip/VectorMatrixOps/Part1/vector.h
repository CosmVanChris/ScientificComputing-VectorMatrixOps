#ifndef VECTOR_H
#define VECTOR_H


#include <stdio.h>
#include <stdlib.h>
#include <time.h>


extern clock_t start;
extern clock_t end;
extern double *t_used;
double vector_vector(int m, int n, double * vecA, double *vecB);



#endif
