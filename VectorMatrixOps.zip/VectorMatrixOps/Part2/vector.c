#include "vector.h"


/**
 * vector_vector - A vector-vector multiplication function
 *
 * Description: This function is a serial code that multplies two vectors and returns a scaler
 *
 * @m: This parameter is the dimension of the first vector A
 * @n: This parameter also represents the dimension of the second vector B
 * @vecA: This is a pointer to the first vector A
 * @vecB: This is also a pointer to the second vector B.
 *
 * Return: A double.
 */

double vector_vector(int m, int n, double *vecA, double *vecB){
	double results = 0;
	int i;
	start = MPI_Wtime();

	for (i = 0; i <= m; i++){
		results += vecA[i] * vecB[i];
	}
	end = MPI_Wtime();
	t_used = (double *)malloc(sizeof(double));
	if (t_used != NULL){
		*t_used = ((double)(end - start));
	}
	return (results);
}
